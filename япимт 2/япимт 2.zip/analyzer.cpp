#include "analyzer.h"
#include "tables.h"


bool Analyzer::isAtEnd() const {
    return pos >= (int)tokens.size();
}

Token Analyzer::current() const {
    if (isAtEnd()) return { TK_EOF, -1, -1, -1, "" };
    return tokens[pos];
}

Token Analyzer::advance() {
    if (!isAtEnd()) pos++;
    return tokens[pos - 1];
}

bool Analyzer::check(TokenKind kind, const string& lexeme) const {
    if (isAtEnd()) return false;
    if (tokens[pos].kind != kind) return false;
    if (!lexeme.empty() && tokens[pos].lexeme != lexeme) return false;
    return true;
}

bool Analyzer::match(TokenKind kind, const string& lexeme) {
    if (!check(kind, lexeme)) return false;
    advance();
    return true;
}

void Analyzer::errorHere(const string& msg) {
    Token t = current();
    err << "SEM_ERR line=" << t.line
        << " col=" << t.col
        << " : " << msg << "\n";
}

void Analyzer::errorToken(const Token& t, const string& msg) {
    err << "SEM_ERR line=" << t.line
        << " col=" << t.col
        << " : " << msg << "\n";
}

bool Analyzer::expect(TokenKind kind, const string& msg, const string& lexeme) {
    if (check(kind, lexeme)) {
        advance();
        return true;
    }
    errorHere(msg);
    return false;
}

int Analyzer::parsePrimary() {
    if (check(TK_CNST)) {
        Token t = advance();
        postfix.push_back(t.lexeme);

        int val = 0;
        try {
            val = stoi(t.lexeme);
        }
        catch (...) {
            errorToken(t, "invalid integer constant");
        }
        return val;
    }

    if (check(TK_ID)) {
        Token t = advance();
        if (!table.isDeclared(t.lexeme)) {
            errorToken(t, "identifier '" + t.lexeme + "' used before declaration");
            return 0;
        }

        postfix.push_back(t.lexeme);

        int val = 0;
        if (!table.getIntValue(t.lexeme, val)) {
            return 0;
        }
        return val;
    }

    if (match(TK_SEP, "(")) {
        int val = parseExpression();
        expect(TK_SEP, "expected ')'", ")");
        return val;
    }

    errorHere("expected constant, identifier or '('");
    if (!isAtEnd()) advance();
    return 0;
}

int Analyzer::parseUnary() {
    if (match(TK_OP, "+")) {
        int v = parseUnary();
        postfix.push_back("u+");
        return v;
    }

    if (match(TK_OP, "-")) {
        int v = parseUnary();
        postfix.push_back("u-");
        return -v;
    }

    if (match(TK_OP, "!")) {
        int v = parseUnary();
        postfix.push_back("!");
        return !v;
    }

    return parsePrimary();
}

int Analyzer::parseMul() {
    int left = parseUnary();

    while (true) {
        if (match(TK_OP, "*")) {
            int r = parseUnary();
            postfix.push_back("*");
            left = left * r;
        }
        else if (match(TK_OP, "/")) {
            int r = parseUnary();
            postfix.push_back("/");

            if (r == 0) {
                errorToken(tokens[pos - 1], "division by zero");
                left = 0;
            }
            else {
                left = left / r;
            }
        }
        else if (match(TK_OP, "%")) {
            int r = parseUnary();
            postfix.push_back("%");

            if (r == 0) {
                errorToken(tokens[pos - 1], "modulo by zero");
                left = 0;
            }
            else {
                left = left % r;
            }
        }
        else {
            break;
        }
    }

    return left;
}

int Analyzer::parseAdd() {
    int left = parseMul();

    while (true) {
        if (match(TK_OP, "+")) {
            int r = parseMul();
            postfix.push_back("+");
            left = left + r;
        }
        else if (match(TK_OP, "-")) {
            int r = parseMul();
            postfix.push_back("-");
            left = left - r;
        }
        else {
            break;
        }
    }

    return left;
}

int Analyzer::parseRel() {
    int left = parseAdd();

    while (true) {
        if (match(TK_OP, "<")) {
            int r = parseAdd();
            postfix.push_back("<");
            left = (left < r);
        }
        else if (match(TK_OP, ">")) {
            int r = parseAdd();
            postfix.push_back(">");
            left = (left > r);
        }
        else if (match(TK_OP, "<=")) {
            int r = parseAdd();
            postfix.push_back("<=");
            left = (left <= r);
        }
        else if (match(TK_OP, ">=")) {
            int r = parseAdd();
            postfix.push_back(">=");
            left = (left >= r);
        }
        else {
            break;
        }
    }

    return left;
}

int Analyzer::parseEq() {
    int left = parseRel();

    while (true) {
        if (match(TK_OP, "==")) {
            int r = parseRel();
            postfix.push_back("==");
            left = (left == r);
        }
        else if (match(TK_OP, "!=")) {
            int r = parseRel();
            postfix.push_back("!=");
            left = (left != r);
        }
        else {
            break;
        }
    }

    return left;
}

int Analyzer::parseAnd() {
    int left = parseEq();

    while (match(TK_OP, "&&")) {
        int r = parseEq();
        postfix.push_back("&&");
        left = (left && r);
    }

    return left;
}

int Analyzer::parseOr() {
    int left = parseAnd();

    while (match(TK_OP, "||")) {
        int r = parseAnd();
        postfix.push_back("||");
        left = (left || r);
    }

    return left;
}

int Analyzer::parseExpression() {
    return parseOr();
}

void Analyzer::parseConstDeclaration() {
    Token constTok = advance(); // const

    if (!check(TK_KW, "int")) {
        errorHere("expected 'int' after 'const'");
        return;
    }

    Token intTok = advance();

    if (intTok.line != constTok.line) {
        errorToken(intTok, "line break between 'const' and 'int' is not allowed");
    }

    if (!check(TK_ID)) {
        errorHere("expected identifier after 'const int'");
        return;
    }

    Token idTok = advance();

    if (idTok.line != intTok.line) {
        errorToken(idTok, "line break after 'const int' is not allowed");
    }

    if (!isNamedConstLexeme(idTok.lexeme)) {
        errorToken(idTok, "'" + idTok.lexeme + "' is not a valid constant name");
    }

    if (!expect(TK_OP, "expected '=' in const declaration", "=")) return;

    postfix.push_back(idTok.lexeme);
    int value = parseExpression();
    postfix.push_back("=");
    postfix.push_back(";");

    if (!expect(TK_SEP, "expected ';' after const declaration", ";")) return;

    if (!table.declareNamedConst(idTok.lexeme, value)) {
        errorToken(idTok, "redefinition of '" + idTok.lexeme + "'");
    }
}

void Analyzer::parseDeclaration() {
    Token intTok = advance(); // int

    while (true) {
        if (!check(TK_ID)) {
            errorHere("expected identifier in declaration");
            return;
        }

        Token idTok = advance();

        if (idTok.line != intTok.line) {
            errorToken(idTok, "line break after 'int' is not allowed");
        }

        if (isNamedConstLexeme(idTok.lexeme)) {
            errorToken(idTok, "identifier with constant-style name must be declared as const");
        }

        if (!table.declareVariable(idTok.lexeme)) {
            errorToken(idTok, "redefinition of '" + idTok.lexeme + "'");
        }

        if (match(TK_OP, "=")) {
            postfix.push_back(idTok.lexeme);
            int value = parseExpression();
            postfix.push_back("=");
            postfix.push_back(";");
            table.assignValueToVariable(idTok.lexeme, value);
        }

        if (match(TK_SEP, ",")) {
            continue;
        }

        if (match(TK_SEP, ";")) {
            break;
        }

        errorHere("expected ',' or ';' in declaration");
        return;
    }
}

void Analyzer::parseAssignment() {
    Token idTok = advance(); // id

    if (!table.isDeclared(idTok.lexeme)) {
        errorToken(idTok, "identifier '" + idTok.lexeme + "' used before declaration");
    }

    if (table.isNamedConst(idTok.lexeme)) {
        errorToken(idTok, "cannot assign to named constant '" + idTok.lexeme + "'");
    }

    if (!expect(TK_OP, "expected '=' in assignment", "=")) return;

    postfix.push_back(idTok.lexeme);   // левый операнд присваивания
    int value = parseExpression();
    postfix.push_back("=");
    postfix.push_back(";");

    if (!expect(TK_SEP, "expected ';' after assignment", ";")) return;

    table.assignValueToVariable(idTok.lexeme, value);
}

void Analyzer::parseStatement() {
    if (check(TK_KW, "const")) {
        parseConstDeclaration();
        return;
    }

    if (check(TK_KW, "int")) {
        parseDeclaration();
        return;
    }

    if (check(TK_ID)) {
        parseAssignment();
        return;
    }

    errorHere("unexpected token '" + current().lexeme + "'");
    advance();
}

Analyzer::Analyzer(const vector<Token>& toks, MutableTable& tbl, ofstream& e)
    : tokens(toks), pos(0), table(tbl), err(e) {
}

void Analyzer::analyzeProgram() {
    while (!isAtEnd()) {
        parseStatement();
    }
}

void analyze(const string& datFile, const string& semErrFile,
    StaticTable& kw, StaticTable& op, StaticTable& sep,
    MutableTable& table){
    vector<Token> tokens = readTokensFromData(datFile, kw, op, sep, table);

    ofstream err(semErrFile);
    Analyzer analyzer(tokens, table, err);
    analyzer.analyzeProgram();
}

